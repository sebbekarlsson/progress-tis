import yaml


with open('tis/urls.yml', 'r') as stream:
    urls = yaml.load(stream)
