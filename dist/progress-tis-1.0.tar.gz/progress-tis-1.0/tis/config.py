import yaml


with open('tis/config.yml', 'r') as stream:
    config = yaml.load(stream)
